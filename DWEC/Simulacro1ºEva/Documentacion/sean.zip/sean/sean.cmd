
;-| Button Remapping |-----------------------------------------------------
; This section lets you remap the player's buttons (to easily change the
; button configuration). The format is:
;   old_button = new_button
; If new_button is left blank, the button cannot be pressed.
[Remap]
x = x
y = y
z = z
a = a
b = b
c = c
s = s

;-| Default Values |-------------------------------------------------------
[Defaults]
; Default value for the "time" parameter of a Command. Minimum 1.
command.time = 15

; Default value for the "buffer.time" parameter of a Command. Minimum 1,
; maximum 30.
command.buffer.time = 1


;-| Super Motions |--------------------------------------------------------
;The following two have the same name, but different motion.
;Either one will be detected by a "command = TripleKFPalm" trigger.
;Time is set to 20 (instead of default of 15) to make the move
;easier to do.
;

[Command]
name = "SA"
command = ~D, DF, F, D, DF, x
time = 20

[Command]
name = "SA"
command = ~D, DF, F, D, DF, y
time = 20

[Command]
name = "SA"
command = ~D, DF, F, D, DF, z
time = 20

[Command]
name = "SA"
command = ~D, DF, F, D, DF, ~x
time = 20

[Command]
name = "SA"
command = ~D, DF, F, D, DF, ~y
time = 20

[Command]
name = "SA"
command = ~D, DF, F, D, DF, ~z
time = 20

[Command]
name = "����葬����"
command = ~D, DF, F, D, DF, a
time = 20

[Command]
name = "����葬����"
command = ~D, DF, F, D, DF, b
time = 20

[Command]
name = "����葬����"
command = ~D, DF, F, D, DF, c
time = 20

[Command]
name = "����葬����"
command = ~D, DF, F, D, DF, ~a
time = 20

[Command]
name = "����葬����"
command = ~D, DF, F, D, DF, ~b
time = 20

[Command]
name = "����葬����"
command = ~D, DF, F, D, DF, ~c
time = 20

;-| Special Motions |------------------------------------------------------

[Command]
name = "�h���S���X�}�b�V��EX"
command = ~F, D, DF, x+y

[Command]
name = "�h���S���X�}�b�V��EX"
command = ~F, D, DF, x+z

[Command]
name = "�h���S���X�}�b�V��EX"
command = ~F, D, DF, y+z

[Command]
name = "�h���S���X�}�b�V��EX"
command = ~F, D, DF, ~x+y

[Command]
name = "�h���S���X�}�b�V��EX"
command = ~F, D, DF, ~x+z

[Command]
name = "�h���S���X�}�b�V��EX"
command = ~F, D, DF, ~y+z

[Command]
name = "�V���[���^�b�N��EX1"
command = ~B, D, F, x+y

[Command]
name = "�V���[���^�b�N��EX2"
command = ~B, D, F, x+z

[Command]
name = "�V���[���^�b�N��EX3"
command = ~B, D, F, y+z

[Command]
name = "�V���[���^�b�N��EX1"
command = ~B, D, F, ~x+y

[Command]
name = "�V���[���^�b�N��EX2"
command = ~B, D, F, ~x+z

[Command]
name = "�V���[���^�b�N��EX3"
command = ~B, D, F, ~y+z

[Command]
name = "�g���l�[�hEX"
command = ~D, DB, B, a+b

[Command]
name = "�g���l�[�hEX"
command = ~D, DB, B, a+c

[Command]
name = "�g���l�[�hEX"
command = ~D, DB, B, b+c

[Command]
name = "�g���l�[�hEX"
command = ~D, DB, B, ~a+b

[Command]
name = "�g���l�[�hEX"
command = ~D, DB, B, ~a+c

[Command]
name = "�g���l�[�hEX"
command = ~D, DB, B, ~b+c

[Command]
name = "�����E�r�L���NEX"
command = ~D, DF, F, a+b

[Command]
name = "�����E�r�L���NEX"
command = ~D, DF, F, a+c

[Command]
name = "�����E�r�L���NEX"
command = ~D, DF, F, b+c

[Command]
name = "�����E�r�L���NEX"
command = ~D, DF, F, ~a+b

[Command]
name = "�����E�r�L���NEX"
command = ~D, DF, F, ~a+c

[Command]
name = "�����E�r�L���NEX"
command = ~D, DF, F, ~b+c

[Command]
name = "�h���S���X�}�b�V����"
command = ~F, D, DF, ~x

[Command]
name = "�h���S���X�}�b�V����"
command = ~F, D, DF, ~y

[Command]
name = "�h���S���X�}�b�V����"
command = ~F, D, DF, ~z

[Command]
name = "�h���S���X�}�b�V����"
command = ~F, D, DF, x

[Command]
name = "�h���S���X�}�b�V����"
command = ~F, D, DF, y

[Command]
name = "�h���S���X�}�b�V����"
command = ~F, D, DF, z

[Command]
name = "�V���[���^�b�N����"
command = ~B, D, F, x

[Command]
name = "�V���[���^�b�N����"
command = ~B, D, F, y

[Command]
name = "�V���[���^�b�N����"
command = ~B, D, F, z

[Command]
name = "�V���[���^�b�N����"
command = ~B, D, F, ~x

[Command]
name = "�V���[���^�b�N����"
command = ~B, D, F, ~y

[Command]
name = "�V���[���^�b�N����"
command = ~B, D, F, ~z

[Command]
name = "�g���l�[�h��"
command = ~D, DB, B, a

[Command]
name = "�g���l�[�h��"
command = ~D, DB, B, b

[Command]
name = "�g���l�[�h��"
command = ~D, DB, B, c

[Command]
name = "�g���l�[�h��"
command = ~D, DB, B, ~a

[Command]
name = "�g���l�[�h��"
command = ~D, DB, B, ~b

[Command]
name = "�g���l�[�h��"
command = ~D, DB, B, ~c

[Command]
name = "�����E�r�L���N��"
command = ~D, DF, F, a

[Command]
name = "�����E�r�L���N��"
command = ~D, DF, F, b

[Command]
name = "�����E�r�L���N��"
command = ~D, DF, F, c

[Command]
name = "�����E�r�L���N��"
command = ~D, DF, F, ~a

[Command]
name = "�����E�r�L���N��"
command = ~D, DF, F, ~b

[Command]
name = "�����E�r�L���N��"
command = ~D, DF, F, ~c

[Command]
name = "�O�]��"
command = ~D, DB, B, x

[Command]
name = "�O�]��"
command = ~D, DB, B, y

[Command]
name = "�O�]��"
command = ~D, DB, B, z

[Command]
name = "�O�]��"
command = ~D, DB, B, ~x

[Command]
name = "�O�]��"
command = ~D, DB, B, ~y

[Command]
name = "�O�]��"
command = ~D, DB, B, ~z

;-| Double Tap |-----------------------------------------------------------
[Command]
name = "FF"     ;Required (do not remove)
command = F, F
time = 10

[Command]
name = "BB"     ;Required (do not remove)
command = B, B
time = 10

[Command]
name = "highjump"
command = D, $U
time = 8

;-| 2/3 Button Combination |-----------------------------------------------
[Command]
name = "recovery";Required (do not remove)
command = x
time = 1

[Command]
name = "recovery";Required (do not remove)
command = y
time = 1

[Command]
name = "recovery";Required (do not remove)
command = z
time = 1

[Command]
name = "recovery";Required (do not remove)
command = a
time = 1

[Command]
name = "recovery";Required (do not remove)
command = b
time = 1

[Command]
name = "recovery";Required (do not remove)
command = c
time = 1

[Command]
name = "�X���["
command = x+a

[Command]
name = "���[�v�A�^�b�N"
command = y+b

[Command]
name = "�f�X�o�E���h"
command = z+c

;-| Dir + Button |---------------------------------------------------------
[Command]
name = "fwd_c"
command = /F,c
time = 1

[Command]
name = "fwd_z"
command = /F,z
time = 1

[Command]
name = "down_a"
command = /$D,a
time = 1

[Command]
name = "down_b"
command = /$D,b
time = 1

;-| Single Button |---------------------------------------------------------

[Command]
name = "fwd"
command = F
time = 1

[Command]
name = "back"
command = B
time = 1

[Command]
name = "up"
command = U
time = 1

[Command]
name = "down"
command = D
time = 1

[Command]
name = "a"
command = a
time = 1

[Command]
name = "b"
command = b
time = 1

[Command]
name = "c"
command = c
time = 1

[Command]
name = "x"
command = x
time = 1

[Command]
name = "y"
command = y
time = 1

[Command]
name = "z"
command = z
time = 1

[Command]
name = "start"
command = s
time = 1

;-| Hold Dir |--------------------------------------------------------------
[Command]
name = "holdfwd";Required (do not remove)
command = /$F
time = 1

[Command]
name = "holdback";Required (do not remove)
command = /$B
time = 1

[Command]
name = "holdup" ;Required (do not remove)
command = /$U
time = 1

[Command]
name = "holddown";Required (do not remove)
command = /$D
time = 1

[Command]
name = "hold_x"
command = /x
time = 1

[Command]
name = "hold_y"
command = /y
time = 1

[Command]
name = "hold_z"
command = /z
time = 1

[Statedef -1]

;===========================================================================
;---------------------------------------------------------------------------



[State -1, Hadou-Burst]
type = varset
var(38) = 3000
triggerall = command = "SA"
triggerall = var(58) = 2
triggerall = power >= 720
triggerall = statetype != A
triggerall = var(38) = 0
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Shouryuu-Cannon]
type = varset
var(38) = 3100
triggerall = command = "SA"
triggerall = var(58) = 3
triggerall = power >= 960
triggerall = statetype != A
triggerall = var(38) = 0
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Hyper-Tornado]
type = varset
var(38) = 3200
triggerall = command = "SA"
triggerall = var(58) = 4
triggerall = power >= 1200
triggerall = statetype != A
triggerall = var(38) = 0
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Hyper-Tornado]
type = varset
var(38) = 3400
triggerall = command = "����葬����"
triggerall = (var(58) = 2 && power >= 720) || (var(58) = 3 && power >= 960) || (var(58) = 4 && power >= 1200)
triggerall = statetype != A
triggerall = var(38) = 0
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, EX Dragon Smash]
type = varset
var(38) = 1150
triggerall = command = "�h���S���X�}�b�V��EX"
triggerall = power >= 400
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Strong Dragon Smash]
type = varset
var(38) = 1120
triggerall = command = "�h���S���X�}�b�V����"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Medium Dragon Smash]
type = varset
var(38) = 1110
triggerall = command = "�h���S���X�}�b�V����"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Light Dragon Smash]
type = varset
var(38) = 1100
triggerall = command = "�h���S���X�}�b�V����"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, EX Sean Tackle]
type = varset
var(38) = 1050
triggerall = command = "�V���[���^�b�N��EX1"||command = "�V���[���^�b�N��EX2"||command = "�V���[���^�b�N��EX3"
triggerall = power >= 400
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Strong Sean Tackle]
type = varset
var(38) = 1006
triggerall = command = "�V���[���^�b�N����"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Medium Sean Tackle]
type = varset
var(38) = 1005
triggerall = command = "�V���[���^�b�N����"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Light Sean Tackle]
type = varset
var(38) = 1000
triggerall = command = "�V���[���^�b�N����"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, EX Tornado]
type = varset
var(38) = 1250
triggerall = command = "�g���l�[�hEX"
triggerall = var(38) = 0
triggerall = power >= 400
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Strong Tornado]
type = varset
var(38) = 1220
triggerall = command = "�g���l�[�h��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Medium Tornado]
type = varset
var(38) = 1210
triggerall = command = "�g���l�[�h��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Light Tornado]
type = varset
var(38) = 1200
triggerall = command = "�g���l�[�h��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, EX Ryuubi Kyaku]
type = varset
var(38) = 1350
triggerall = command = "�����E�r�L���NEX"
triggerall = power >= 400
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Strong Ryuubi Kyaku]
type = varset
var(38) = 1320
triggerall = command = "�����E�r�L���N��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Medium Ryuubi Kyaku]
type = varset
var(38) = 1310
triggerall = command = "�����E�r�L���N��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Light Ryuubi Kyaku]
type = varset
var(38) = 1300
triggerall = command = "�����E�r�L���N��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, �O�]��]
type = varset
var(38) = 1420
triggerall = command = "�O�]��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, �O�]��]
type = varset
var(38) = 1410
triggerall = command = "�O�]��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, �O�]��]
type = varset
var(38) = 1400
triggerall = command = "�O�]��"
triggerall = var(38) = 0
trigger1 = statetype != A
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Seoi Throw]
type = varset
var(38) = 800
triggerall = command = "�X���["
triggerall = var(38) = 0
triggerall = statetype = S || statetype = C
triggerall = command != "holdup"
triggerall = command != "holddown"
triggerall = command != "holdback" || (p2dist x < 0 && command = "holdback")
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Tomoe Throw]
type = varset
var(38) = 805
triggerall = command = "�X���["
triggerall = var(38) = 0
triggerall = statetype = S || statetype = C
triggerall = command = "holdback"
triggerall = command != "holdup"
triggerall = command != "holddown"
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Leap Attack]
type = varset
var(38) = 700
triggerall = command = "���[�v�A�^�b�N"
triggerall = var(38) = 0
triggerall = statetype = S || statetype = C
triggerall = command != "holdback"
triggerall = command != "holdfwd"
triggerall = command != "holdup"
triggerall = command != "holddown"
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, PA]
type = varset
var(38) = ifelse(numhelper(197),196,195)
triggerall = command = "�f�X�o�E���h"
triggerall = var(38) = 0
triggerall = statetype = S || statetype = C
triggerall = command != "holdback"
triggerall = command != "holdfwd"
triggerall = command != "holdup"
triggerall = command != "holddown"
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0



;---------------------------------------------------------------------------
[State -1, Forward Strong Punch]
type = varset
var(38) = 260
triggerall = command = "fwd_z"
triggerall = command != "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Forward Strong Kick]
type = varset
var(38) = 270
triggerall = command = "fwd_c"
triggerall = command != "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Stand Strong Punch]
type = varset
var(38) = 220
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = var(38) = 0
triggerall = (p2dist x>=0&&(p2bodydist x=[-ceil(var(11)*0.9),ceil(var(11)*0.9)]))||(p2dist x<0&&(p2bodydist x=[-ceil(var(11)*1.8),-ceil(var(11)*0.9)]))
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Stand Strong Punch]
type = varset
var(38) = 225
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = var(38) = 0
triggerall = p2bodydist x > ceil(var(11)*0.9) || p2bodydist x < -ceil(var(11)*0.9)
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Stand Medium Punch]
type = varset
var(38) = 210
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = var(38) = 0
triggerall = (p2dist x>=0&&(p2bodydist x=[-ceil(var(11)*0.8),ceil(var(11)*0.8)]))||(p2dist x<0&&(p2bodydist x=[-ceil(var(11)*1.6),-ceil(var(11)*0.8)]))
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Stand Medium Punch]
type = varset
var(38) = 215
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = var(38) = 0
triggerall = p2bodydist x > ceil(var(11)*0.8) || p2bodydist x < -ceil(var(11)*0.8)
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Stand Light Punch]
type = varset
var(38) = 200
triggerall = command = "x"
triggerall = command != "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Standing Strong Kick]
type = varset
var(38) = 250
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = var(38) = 0
triggerall = (p2dist x>=0&&(p2bodydist x=[-var(11)*1.2,var(11)*1.2]))||(p2dist x<0&&(p2bodydist x=[-(var(11)*2.4),-var(11)*1.2]))
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

[State -1, Standing Strong Kick]
type = varset
var(38) = 255
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = var(38) = 0
triggerall = p2bodydist x > var(11)*1.2 || p2bodydist x < -var(11)*1.2
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Standing Medium Kick]
type = varset
var(38) = 240
triggerall = command = "b"
triggerall = command != "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Stand Light Kick]
type = varset
var(38) = 230
triggerall = command = "a"
triggerall = command != "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Crouching Strong Punch]
type = varset
var(38) = 420
triggerall = command = "z"
triggerall = command = "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Crouching Medium Punch]
type = varset
var(38) = 410
triggerall = command = "y"
triggerall = command = "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Crouching Light Punch]
type = varset
var(38) = 400
triggerall = command = "x"
triggerall = command = "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Crouching Strong Kick]
type = varset
var(38) = 450
triggerall = command = "c"
triggerall = command = "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Crouching Medium Kick]
type = varset
var(38) = 440
triggerall = command = "b"
triggerall = command = "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------
[State -1, Crouching Light Kick]
type = varset
var(38) = 430
triggerall = command = "a"
triggerall = command = "holddown"
triggerall = var(38) = 0
trigger1 = statetype = S || statetype = C
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) < 0

;---------------------------------------------------------------------------




[State 131, 1]
type = varset
triggerall = !var(39)
trigger1 = var(37) >= 3000

var(39) = 20

[State 131, 1]
type = varset
triggerall = !var(39)
trigger1 = var(37) < 3000

var(39) = 15

[State 131, 1]
type = varadd
trigger1 = var(39) > 0
trigger1 = 1
var(39) = -1
persistent = 1

[State -1]
type = ChangeState
value = var(38)
triggerall = var(38)=[195,3999]
trigger1 = stateno = [90,93]
trigger1 = AnimElemTime(4) = 0

[State -1]
type = varset
var(38) = 0
trigger1 = var(38)=[195,3999]
trigger1 = stateno=[195,3999]
trigger2 = movetype = H
;trigger3 = var(39) = 0







[State -1, Hadou-Burst]
type = ChangeState
value = 3000
triggerall = roundstate = 2
triggerall = command = "SA"
triggerall = var(58) = 2
triggerall = power >= 720
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 5120&&AnimTime = 0) || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || (stateno = [40,41])
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = (stateno = 420 && var(19)>=2) || stateno != 420
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

trigger6 = (movecontact||movereversed) && var(19)
trigger6 = stateno = [1100,1150]

[State -1, Shouryuu-Cannon]
type = ChangeState
value = 3100
triggerall = roundstate = 2
triggerall = command = "SA"
triggerall = var(58) = 3
triggerall = power >= 960
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 5120&&AnimTime = 0) || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || (stateno = [40,41])
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = (stateno = 420 && var(19)>=2) || stateno != 420
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

trigger6 = (movecontact||movereversed) && var(19)
trigger6 = stateno = [1100,1150]

[State -1, Hyper-Tornado]
type = ChangeState
value = 3200
triggerall = roundstate = 2
triggerall = command = "SA"
triggerall = var(58) = 4
triggerall = power >= 1200
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 5120&&AnimTime = 0) || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || (stateno = [40,41])
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = (stateno = 420 && var(19)>=2) || stateno != 420
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

trigger6 = (movecontact||movereversed) && var(19)
trigger6 = stateno = [1100,1150]

[State -1, Hyper-Tornado]
type = ChangeState
value = 3400
triggerall = roundstate = 2
triggerall = command = "����葬����"
triggerall = (var(58) = 2 && power >= 720) || (var(58) = 3 && power >= 960) || (var(58) = 4 && power >= 1200)
triggerall = statetype != A
trigger1 = ctrl || (StateNo = 5120&&AnimTime = 0) || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || (stateno = [40,41])
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = (stateno = 420 && var(19)>=2) || stateno != 420
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

trigger6 = (movecontact||movereversed) && var(19)
trigger6 = stateno = [1100,1150]

;---------------------------------------------------------------------------
[State -1, EX Dragon Smash]
type = ChangeState
value = 1150
triggerall = roundstate = 2
triggerall = command = "�h���S���X�}�b�V��EX"
triggerall = power >= 400
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Strong Dragon Smash]
type = ChangeState
value = 1120
triggerall = roundstate = 2
triggerall = command = "�h���S���X�}�b�V����"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Medium Dragon Smash]
type = ChangeState
value = 1110
triggerall = roundstate = 2
triggerall = command = "�h���S���X�}�b�V����"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Light Dragon Smash]
type = ChangeState
value = 1100
triggerall = roundstate = 2
triggerall = command = "�h���S���X�}�b�V����"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

;---------------------------------------------------------------------------
[State -1, EX Sean Tackle]
type = ChangeState
value = 1050
triggerall = roundstate = 2
triggerall = command = "�V���[���^�b�N��EX1"||command = "�V���[���^�b�N��EX2"||command = "�V���[���^�b�N��EX3"
triggerall = power >= 400
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Strong Sean Tackle]
type = ChangeState
value = 1006
triggerall = roundstate = 2
triggerall = command = "�V���[���^�b�N����"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Medium Sean Tackle]
type = ChangeState
value = 1005
triggerall = roundstate = 2
triggerall = command = "�V���[���^�b�N����"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Light Sean Tackle]
type = ChangeState
value = 1000
triggerall = roundstate = 2
triggerall = command = "�V���[���^�b�N����"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

;---------------------------------------------------------------------------
[State -1, EX Tornado]
type = ChangeState
value = 1250
triggerall = roundstate = 2
triggerall = command = "�g���l�[�hEX"
triggerall = power >= 400
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Strong Tornado]
type = ChangeState
value = 1220
triggerall = roundstate = 2
triggerall = command = "�g���l�[�h��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Medium Tornado]
type = ChangeState
value = 1210
triggerall = roundstate = 2
triggerall = command = "�g���l�[�h��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Light Tornado]
type = ChangeState
value = 1200
triggerall = roundstate = 2
triggerall = command = "�g���l�[�h��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

;---------------------------------------------------------------------------
[State -1, EX Ryuubi Kyaku]
type = ChangeState
value = 1350
triggerall = roundstate = 2
triggerall = command = "�����E�r�L���NEX"
triggerall = power >= 400
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Strong Ryuubi Kyaku]
type = ChangeState
value = 1320
triggerall = roundstate = 2
triggerall = command = "�����E�r�L���N��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Medium Ryuubi Kyaku]
type = ChangeState
value = 1310
triggerall = roundstate = 2
triggerall = command = "�����E�r�L���N��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, Light Ryuubi Kyaku]
type = ChangeState
value = 1300
triggerall = roundstate = 2
triggerall = command = "�����E�r�L���N��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

;---------------------------------------------------------------------------
[State -1, �O�]��]
type = ChangeState
value = 1420
triggerall = roundstate = 2
triggerall = command = "�O�]��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, �O�]��]
type = ChangeState
value = 1410
triggerall = roundstate = 2
triggerall = command = "�O�]��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

[State -1, �O�]��]
type = ChangeState
value = 1400
triggerall = roundstate = 2
triggerall = command = "�O�]��"
trigger1 = statetype != A
trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = stateno = 12 || stateno = 40
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger4 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger5 = (movecontact||movereversed) && var(19)
trigger5 = stateno = [200,440]
trigger5 = stateno != 215 && stateno != 225
trigger5 = stateno != 230 && stateno != 240
trigger5 = stateno != [255,275]

;===========================================================================
;---------------------------------------------------------------------------
;Run Fwd
;�_�b�V��
[State -1, Run Fwd]
type = ChangeState
value = 100
trigger1 = command = "FF"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;Run Back
;��ރ_�b�V��
[State -1, Run Back]
type = ChangeState
value = 105
trigger1 = command = "BB"
trigger1 = statetype = S
trigger1 = ctrl

;---------------------------------------------------------------------------
;�Z�I�C�X���[
[State -1, Seoi Throw]
type = ChangeState
value = 800
triggerall = command = "�X���["
triggerall = statetype = S || statetype = C
triggerall = stateno != 100
triggerall = command != "holdup"
triggerall = command != "holddown"
triggerall = command != "holdback" || (p2dist x < 0 && command = "holdback")

trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;�g�D���G�X���[
[State -1, Tomoe Throw]
type = ChangeState
value = 805
triggerall = command = "�X���["
triggerall = statetype = S || statetype = C
triggerall = stateno != 100
triggerall = command = "holdback"
triggerall = command != "holdup"
triggerall = command != "holddown"

trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
;���[�v�A�^�b�N
[State -1, Leap Attack]
type = ChangeState
value = 700
triggerall = command = "���[�v�A�^�b�N"
triggerall = statetype = S || statetype = C
triggerall = stateno != 100
triggerall = command != "holdback"
triggerall = command != "holdfwd"
triggerall = command != "holdup"
triggerall = command != "holddown"

trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
;����
[State -1, PA]
type = ChangeState
value = ifelse(numhelper(197),196,195)
triggerall = command = "�f�X�o�E���h"
triggerall = statetype = S || statetype = C
triggerall = stateno != 100
triggerall = command != "holdback"
triggerall = command != "holdfwd"
triggerall = command != "holdup"
triggerall = command != "holddown"

trigger1 = ctrl || (((stateno = [200,270])&&time <= 3)&&(prevstateno != [200,270])&&(!movecontact&&!movereversed))
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

trigger4 = (movecontact||movereversed) && movetype = A
trigger4 = stateno = [200,440]
trigger4 = stateno != 215 && stateno != 225
trigger4 = stateno != 230 && stateno != 240
trigger4 = stateno != [255,275]

;===========================================================================
;---------------------------------------------------------------------------
[State 200, 3];�A�ŃL�����Z���p
type = varset
trigger1 = stateno != [200,599]
trigger2 = time < 2
trigger2 = stateno = [200,599]
trigger3 = ctrl = 1
trigger3 = stateno = [200,599]
ignorehitpause = 1
var(10) = 0

[State 240, 3];�ߋ����F���͈�
type = varset
trigger1 = 1
var(11) = ceil(36*const(Size.xscale))

;===========================================================================
;---------------------------------------------------------------------------
[State -1, Target Combo Stand Medium Punch -> Stand Strong Kick]
type = ChangeState
value = 275
triggerall = command = "c"
triggerall = command != "holddown"
trigger1 = (movecontact||movereversed) && var(19)
trigger1 = stateno = 210

[State -1, Target Combo Stand Strong Punch -> Forward Strong Punch]
type = ChangeState
value = 265
triggerall = command = "fwd_z"
triggerall = command != "holddown"
trigger1 = (movecontact||movereversed) && var(19)
trigger1 = stateno = 220

;---------------------------------------------------------------------------
[State -1, Forward Strong Punch]
type = ChangeState
value = 260
triggerall = command = "fwd_z"
triggerall = command != "holddown"
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Forward Strong Kick]
type = ChangeState
value = 270
triggerall = command = "fwd_c"
triggerall = command != "holddown"
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Stand Strong Punch]
type = ChangeState
value = 220
triggerall = command = "z"
triggerall = command != "holddown"
;triggerall = p2bodydist x = [-30,30]
triggerall = (p2dist x>=0&&(p2bodydist x=[-ceil(var(11)*0.9),ceil(var(11)*0.9)]))||(p2dist x<0&&(p2bodydist x=[-ceil(var(11)*1.8),-ceil(var(11)*0.9)]))
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

[State -1, Stand Strong Punch]
type = ChangeState
value = 225
triggerall = command = "z"
triggerall = command != "holddown"
triggerall = p2bodydist x > ceil(var(11)*0.9) || p2bodydist x < -ceil(var(11)*0.9)
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Stand Medium Punch]
type = ChangeState
value = 210
triggerall = command = "y"
triggerall = command != "holddown"
;triggerall = p2bodydist x = [-30,30]
triggerall = (p2dist x>=0&&(p2bodydist x=[-ceil(var(11)*0.8),ceil(var(11)*0.8)]))||(p2dist x<0&&(p2bodydist x=[-ceil(var(11)*1.6),-ceil(var(11)*0.8)]))
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

[State -1, Stand Medium Punch]
type = ChangeState
value = 215
triggerall = command = "y"
triggerall = command != "holddown"
triggerall = p2bodydist x > ceil(var(11)*0.8) || p2bodydist x < -ceil(var(11)*0.8)
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Stand Light Punch]
type = ChangeState
value = 200
triggerall = command = "x" || (var(10) = 1 && stateno = 200)
triggerall = command != "holddown"
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0
trigger4 = animelemtime(4) >= 0
trigger4 = stateno = 200 || anim = 400
trigger4 = !(movecontact||movereversed)
trigger5 = (movecontact||movereversed)
trigger5 = stateno = 400 || stateno = 430
trigger6 = anim = 401
trigger6 = animelemtime(5) >= 0
trigger6 = !(movecontact||movereversed)
;---------------------------------------------------------------------------
[State -1, Standing Strong Kick]
type = ChangeState
value = 250
triggerall = command = "c"
triggerall = command != "holddown"
;triggerall = p2bodydist x = [-30,30]
triggerall = (p2dist x>=0&&(p2bodydist x=[-var(11)*1.2,var(11)*1.2]))||(p2dist x<0&&(p2bodydist x=[-(var(11)*2.4),-var(11)*1.2]))
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

[State -1, Standing Strong Kick]
type = ChangeState
value = 255
triggerall = command = "c"
triggerall = command != "holddown"
triggerall = p2bodydist x > var(11)*1.2 || p2bodydist x < -var(11)*1.2
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger3 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Standing Medium Kick]
type = ChangeState
value = 240
triggerall = command = "b"
triggerall = command != "holddown"
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Stand Light Kick]
type = ChangeState
value = 230
triggerall = command = "a"
triggerall = command != "holddown"
trigger1 = statetype = S || statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0
trigger4 = (movecontact||movereversed)
trigger4 = stateno = 200
trigger5 = (movecontact||movereversed)
trigger5 = stateno = 400 || stateno = 430
;trigger6 = stateno = 200 || stateno = 400
;trigger6 = animelemtime(4) >= 0

;---------------------------------------------------------------------------
[State -1, Crouching Strong Punch]
type = ChangeState
value = 420
triggerall = command = "z"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Crouching Medium Punch]
type = ChangeState
value = 410
triggerall = command = "y"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Crouching Light Punch]
type = ChangeState
value = 400
triggerall = command = "x"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0
trigger4 = (movecontact||movereversed)
trigger4 = stateno = 200
trigger5 = (movecontact||movereversed)
trigger5 = stateno = 400 || stateno = 430
trigger6 = stateno = 200 || anim = 400
trigger6 = animelemtime(4) >= 0
trigger7 = anim = 401
trigger7 = animelemtime(5) >= 0

;---------------------------------------------------------------------------
[State -1, Crouching Strong Kick]
type = ChangeState
value = 450
triggerall = command = "c"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Crouching Medium Kick]
type = ChangeState
value = 440
triggerall = command = "b"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0

;---------------------------------------------------------------------------
[State -1, Crouching Light Kick]
type = ChangeState
value = 430
triggerall = command = "a"
triggerall = command = "holddown"
trigger1 = statetype = C
trigger1 = ctrl
trigger2 = (stateno = 52 && prevstateno = [600,699]) && time >= 0;time >= 3
trigger3 = (stateno = 52 && prevstateno != [600,699]) && time >= 0
trigger4 = animelemtime(4) >= 0 || (movecontact||movereversed)
trigger4 = stateno = 430
trigger5 = (movecontact||movereversed)
trigger5 = stateno = 400 || stateno = 200
;trigger6 = stateno = 200 || stateno = 400
;trigger6 = animelemtime(4) >= 0

;---------------------------------------------------------------------------
[State -1, Jump Strong Punch]
type = ChangeState
value = 625
triggerall = command = "z"
triggerall= vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

[State -1, Jump Strong Punch]
type = ChangeState
value = 620
triggerall = command = "z"
triggerall= vel x = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

;---------------------------------------------------------------------------
[State -1, Jump Medium Punch]
type = ChangeState
value = 615
triggerall = command = "y"
triggerall= vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

[State -1, Jump Medium Punch]
type = ChangeState
value = 610
triggerall = command = "y"
triggerall= vel x = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

;---------------------------------------------------------------------------
[State -1, Jump Light Punch]
type = ChangeState
value = 605
triggerall = command = "x"
triggerall= vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

[State -1, Jump Light Punch]
type = ChangeState
value = 600
triggerall = command = "x"
triggerall= vel x = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

;---------------------------------------------------------------------------
[State -1, Jump Strong Kick]
type = ChangeState
value = 655
triggerall = command = "c"
triggerall= vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

[State -1, Jump Strong Kick]
type = ChangeState
value = 650
triggerall = command = "c"
triggerall= vel x = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

;---------------------------------------------------------------------------
[State -1, Jump Medium Kick]
type = ChangeState
value = 645
triggerall = command = "b"
triggerall= vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

[State -1, Jump Medium Kick]
type = ChangeState
value = 640
triggerall = command = "b"
triggerall= vel x = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

;---------------------------------------------------------------------------
[State -1, Jump Light Kick]
type = ChangeState
value = 635
triggerall = command = "a"
triggerall= vel x != 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210

[State -1, Jump Light Kick]
type = ChangeState
value = 630
triggerall = command = "a"
triggerall= vel x = 0
trigger1 = statetype = A
trigger1 = ctrl
trigger1 = Anim != 5040 && Anim != 5210
